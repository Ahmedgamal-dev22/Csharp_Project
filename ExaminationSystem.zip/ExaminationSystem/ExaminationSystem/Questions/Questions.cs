﻿using ExaminationSystem.Answers;

namespace ExaminationSystem.Questions
{
    public abstract class Question
    {
        public string Header { get; set; }

        public string Body { get; set; }

        public int Marks { get; set; }

        public AnswerList Answers { get; set; }

        protected Question(
            string header,
            string body,
            int marks,
            AnswerList answers)
        {
            Header = header;
            Body = body;
            Marks = marks;
            Answers = answers;
        }

        public abstract void Display();

        public override string ToString()
        {
            return $"{Header}: {Body} - Marks: {Marks}";
        }
    }
}