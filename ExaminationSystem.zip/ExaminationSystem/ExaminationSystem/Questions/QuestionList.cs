﻿using System.Collections.Generic;
using System.IO;

namespace ExaminationSystem.Questions
{
    public class QuestionList : List<Question>
    {
        private readonly string _filePath;

        public QuestionList(string filePath)
        {
            _filePath = filePath;
        }

        public new void Add(Question question)
        {
            base.Add(question);

            using (StreamWriter writer =
                new StreamWriter(_filePath, true))
            {
                writer.WriteLine(question);
            }
        }
    }
}