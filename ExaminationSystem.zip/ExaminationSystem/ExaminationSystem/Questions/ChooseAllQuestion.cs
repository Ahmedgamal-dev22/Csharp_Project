﻿using System;
using ExaminationSystem.Answers;

namespace ExaminationSystem.Questions
{
    public class ChooseAllQuestion : Question
    {
        public ChooseAllQuestion(
            string header,
            string body,
            int marks,
            AnswerList answers)
            : base(header, body, marks, answers)
        {
        }

        public override void Display()
        {
            Console.WriteLine($"{Header}: {Body}");

            foreach (Answer answer in Answers)
            {
                Console.WriteLine(answer);
            }

            Console.WriteLine("Choose ALL correct answers.");
        }
    }
}