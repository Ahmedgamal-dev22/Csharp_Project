﻿using System;
using ExaminationSystem.Questions;
using ExaminationSystem.Subjects;

namespace ExaminationSystem.Exams
{
    public class FinalExam : Exam
    {
        public FinalExam(
            TimeSpan time,
            int numberOfQuestions,
            Subject subject,
            QuestionList questions)
            : base(time, numberOfQuestions, subject)
        {
            Questions = questions;
        }

        public override void ShowExam()
        {
            Console.WriteLine("Final Exam");
            Console.WriteLine($"Subject: {Subject.Name}");
            Console.WriteLine($"Number of Questions: {NumberOfQuestions}");
            Console.WriteLine();

            foreach (Question question in Questions)
            {
                question.Display();
                Console.WriteLine();
            }

            FinishExam();

            Console.WriteLine("Exam Finished!");
        }
    }
}