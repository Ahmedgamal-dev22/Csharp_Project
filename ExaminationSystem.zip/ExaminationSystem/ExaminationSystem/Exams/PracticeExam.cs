﻿using System;
using ExaminationSystem.Answers;
using ExaminationSystem.Questions;
using ExaminationSystem.Subjects;

namespace ExaminationSystem.Exams
{
    public class PracticeExam : Exam
    {
        public PracticeExam(
            TimeSpan time,
            int numberOfQuestions,
            Subject subject,
            QuestionList questions)
            : base(time, numberOfQuestions, subject)
        {
            Questions = questions;
        }

        public override void ShowExam()
        {
            Console.WriteLine("Practice Exam");
            Console.WriteLine($"Subject: {Subject.Name}");
            Console.WriteLine($"Number of Questions: {NumberOfQuestions}");
            Console.WriteLine();

            foreach (Question question in Questions)
            {
                question.Display();

                if (question is ChooseAllQuestion)
                {
                    Console.WriteLine(
                        "Choose ALL answers separated by comma.");

                    ShowChooseAllResult(question);
                }
                else
                {
                    ShowSingleAnswerResult(question);
                }

                Console.WriteLine();
            }

            FinishExam();

            Console.WriteLine("Exam Finished!");
            Console.WriteLine();

            ShowCorrectAnswers();
        }

        private void ShowSingleAnswerResult(Question question)
        {
            int answerId = ReadAnswerId();

            AnswerList correctAnswers =
                QuestionAnswers[question];

            Answer studentAnswer =
                question.Answers.Find(
                    answer => answer.Id == answerId);

            bool isCorrect =
                studentAnswer != null &&
                correctAnswers.Count > 0 &&
                studentAnswer.Id == correctAnswers[0].Id;

            Console.WriteLine(
                isCorrect
                    ? "Correct Answer!"
                    : "Wrong Answer!");
        }

        private void ShowChooseAllResult(Question question)
        {
            Console.Write("Enter your answers: ");

            string input = Console.ReadLine();

            string[] selectedIds =
                input.Split(
                    ',',
                    StringSplitOptions.RemoveEmptyEntries);

            AnswerList correctAnswers =
                QuestionAnswers[question];

            if (selectedIds.Length != correctAnswers.Count)
            {
                Console.WriteLine("Wrong Answer!");
                return;
            }

            for (int i = 0; i < selectedIds.Length; i++)
            {
                if (!int.TryParse(
                        selectedIds[i].Trim(),
                        out int answerId))
                {
                    Console.WriteLine("Wrong Answer!");
                    return;
                }

                // Prevent duplicate answers
                for (int j = 0; j < i; j++)
                {
                    if (int.TryParse(
                            selectedIds[j].Trim(),
                            out int previousId) &&
                        answerId == previousId)
                    {
                        Console.WriteLine("Wrong Answer!");
                        return;
                    }
                }

                bool found = false;

                foreach (Answer correctAnswer in correctAnswers)
                {
                    if (correctAnswer.Id == answerId)
                    {
                        found = true;
                        break;
                    }
                }

                if (!found)
                {
                    Console.WriteLine("Wrong Answer!");
                    return;
                }
            }

            Console.WriteLine("Correct Answer!");
        }

        private int ReadAnswerId()
        {
            while (true)
            {
                Console.Write("Enter your answer: ");

                if (int.TryParse(
                        Console.ReadLine(),
                        out int answerId))
                {
                    return answerId;
                }

                Console.WriteLine(
                    "Invalid answer. Try again.");
            }
        }

        private void ShowCorrectAnswers()
        {
            Console.WriteLine("Correct Answers:");

            foreach (Question question in Questions)
            {
                AnswerList correctAnswers =
                    QuestionAnswers[question];

                Console.Write($"{question.Header}: ");

                foreach (Answer answer in correctAnswers)
                {
                    Console.Write($"{answer.Text} ");
                }

                Console.WriteLine();
            }
        }
    }
}