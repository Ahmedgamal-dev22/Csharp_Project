﻿using System;
using System.Collections.Generic;
using ExaminationSystem.Answers;
using ExaminationSystem.Questions;
using ExaminationSystem.Subjects;

namespace ExaminationSystem.Exams
{
    public delegate void ExamStartedEventHandler(
        object sender,
        ExamStartedEventArgs e);

    public abstract class Exam : ICloneable, IComparable
    {
        public TimeSpan Time { get; set; }

        public int NumberOfQuestions { get; set; }

        public Dictionary<Question, AnswerList> QuestionAnswers
        {
            get;
            private set;
        }

        public Subject Subject { get; set; }

        public QuestionList Questions { get; protected set; }

        public ExamState State { get; private set; }

        public event ExamStartedEventHandler ExamStarted;

        protected Exam(
            TimeSpan time,
            int numberOfQuestions,
            Subject subject)
        {
            Time = time;
            NumberOfQuestions = numberOfQuestions;
            Subject = subject;

            QuestionAnswers =
                new Dictionary<Question, AnswerList>();

            State = ExamState.Queued;
        }

        protected void OnExamStarted()
        {
            State = ExamState.Starting;

            ExamStarted?.Invoke(
                this,
                new ExamStartedEventArgs(
                    "The exam is starting now."));
        }

        public void StartExam()
        {
            OnExamStarted();
        }

        public void FinishExam()
        {
            State = ExamState.Finished;
        }

        public abstract void ShowExam();

        public object Clone()
        {
            return MemberwiseClone();
        }

        public int CompareTo(object obj)
        {
            if (obj is not Exam otherExam)
            {
                return 1;
            }

            return NumberOfQuestions.CompareTo(
                otherExam.NumberOfQuestions);
        }

        public override bool Equals(object obj)
        {
            if (obj is not Exam otherExam)
            {
                return false;
            }

            return Subject.Id == otherExam.Subject.Id
                && Time == otherExam.Time
                && NumberOfQuestions ==
                   otherExam.NumberOfQuestions;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(
                Subject.Id,
                Time,
                NumberOfQuestions);
        }
    }
}