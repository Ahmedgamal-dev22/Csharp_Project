﻿using System;

namespace ExaminationSystem.Exams
{
    public class ExamStartedEventArgs : EventArgs
    {
        public string Message { get; set; }

        public ExamStartedEventArgs(string message)
        {
            Message = message;
        }
    }
}