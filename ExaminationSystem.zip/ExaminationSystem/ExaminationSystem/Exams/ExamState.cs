﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExaminationSystem.Exams
{
    public enum ExamState
    {
        Starting,
        Queued,
        Finished
    }
}