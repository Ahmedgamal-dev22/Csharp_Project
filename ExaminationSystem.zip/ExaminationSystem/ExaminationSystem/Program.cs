﻿using System;
using ExaminationSystem.Answers;
using ExaminationSystem.Exams;
using ExaminationSystem.Questions;
using ExaminationSystem.Students;
using ExaminationSystem.Subjects;

namespace ExaminationSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            Subject subject = new Subject(1, "C#");
            Student student = new Student(1, "Ahmed");

            QuestionList questions =
                new QuestionList("Questions.txt");

            // Question 1 - True / False
            AnswerList trueFalseAnswers = new AnswerList
            {
                new Answer(1, "True"),
                new Answer(2, "False")
            };

            TrueFalseQuestion question1 =
                new TrueFalseQuestion(
                    "Question 1",
                    "C# is an object-oriented programming language.",
                    5,
                    trueFalseAnswers);

            // Question 2 - Choose One
            AnswerList chooseOneAnswers = new AnswerList
            {
                new Answer(1, "C#"),
                new Answer(2, "HTML"),
                new Answer(3, "CSS")
            };

            ChooseOneQuestion question2 =
                new ChooseOneQuestion(
                    "Question 2",
                    "Which one is a programming language?",
                    5,
                    chooseOneAnswers);

            // Question 3 - Choose All
            AnswerList chooseAllAnswers = new AnswerList
            {
                new Answer(1, "C#"),
                new Answer(2, "Java"),
                new Answer(3, "HTML"),
                new Answer(4, "Python")
            };

            ChooseAllQuestion question3 =
                new ChooseAllQuestion(
                    "Question 3",
                    "Which of the following are programming languages?",
                    5,
                    chooseAllAnswers);

            // Add Questions
            Question[] questionArray =
            {
                question1,
                question2,
                question3
            };

            foreach (Question question in questionArray)
            {
                questions.Add(question);
            }

            // Exams
            PracticeExam practiceExam =
                new PracticeExam(
                    TimeSpan.FromMinutes(60),
                    3,
                    subject,
                    questions);

            FinalExam finalExam =
                new FinalExam(
                    TimeSpan.FromMinutes(120),
                    3,
                    subject,
                    questions);

            // Correct Answers
            practiceExam.QuestionAnswers.Add(
                question1,
                new AnswerList
                {
                    trueFalseAnswers[0]
                });

            practiceExam.QuestionAnswers.Add(
                question2,
                new AnswerList
                {
                    chooseOneAnswers[0]
                });

            practiceExam.QuestionAnswers.Add(
                question3,
                new AnswerList
                {
                    chooseAllAnswers[0],
                    chooseAllAnswers[1],
                    chooseAllAnswers[3]
                });

            // Event using Lambda
            ExamStartedEventHandler notifyStudent =
                (sender, e) =>
                {
                    student.Notify();
                    Console.WriteLine(e.Message);
                };

            practiceExam.ExamStarted += notifyStudent;
            finalExam.ExamStarted += notifyStudent;

            // Choose Exam
            int choice;

            do
            {
                Console.WriteLine("Choose Exam Type:");
                Console.WriteLine("1. Practice Exam");
                Console.WriteLine("2. Final Exam");

                Console.Write("Enter your choice: ");

                bool isValid =
                    int.TryParse(
                        Console.ReadLine(),
                        out choice);

                if (!isValid)
                {
                    Console.WriteLine("Invalid choice.");
                    Console.WriteLine();
                    continue;
                }

                if (choice == 1)
                {
                    practiceExam.StartExam();
                    practiceExam.ShowExam();
                }
                else if (choice == 2)
                {
                    finalExam.StartExam();
                    finalExam.ShowExam();
                }
                else
                {
                    Console.WriteLine("Invalid choice.");
                    Console.WriteLine();
                }

            } while (choice != 1 && choice != 2);
        }
    }
}