﻿namespace ExaminationSystem.Students
{
    public class Student
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public Student(int id, string name)
        {
            Id = id;
            Name = name;
        }

        public void Notify()
        {
            System.Console.WriteLine(
                $"Student {Name} has been notified.");
        }

        public override string ToString()
        {
            return $"{Id} - {Name}";
        }
    }
}