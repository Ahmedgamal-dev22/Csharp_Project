﻿using System.Collections.Generic;

namespace ExaminationSystem.Answers
{
    public class AnswerList : List<Answer>
    {
    }
}